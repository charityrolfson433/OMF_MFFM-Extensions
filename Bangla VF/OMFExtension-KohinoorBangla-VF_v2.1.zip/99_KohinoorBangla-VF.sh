# Kohinoor Bangla Variable - Extension For OMF
# v2.1
# 2022/10/13

# Instructions
# Copy this .sh and ttf file to the $OMFDIR (internal storage/OMF)

[ $OMFDIR/KohinoorBangla-VF.ttf ] && cp $OMFDIR/KohinoorBangla-VF.ttf $SYSFONT/NotoSansBengali-VF.ttf;

# Weight <wght@300..700>
# Change the below values of the variable font weight to 

Light='350'
Regular='460'
Medium='555'
SemiBold='650'
Bold='700'

#Don't change anything after this.
echo "		<font weight=\"300\" style=\"normal\">NotoSansBengali-VF.ttf
		    <axis tag=\"wght\" stylevalue=\"$Light\"/>
		</font>
		<font weight=\"400\" style=\"normal\">NotoSansBengali-VF.ttf
            <axis tag=\"wght\" stylevalue=\"$Regular\"/>
        </font>
        <font weight=\"500\" style=\"normal\">NotoSansBengali-VF.ttf
            <axis tag=\"wght\" stylevalue=\"$Medium\"/>
        </font>
        <font weight=\"600\" style=\"normal\">NotoSansBengali-VF.ttf
            <axis tag=\"wght\" stylevalue=\"$SemiBold\"/>
        </font>
        <font weight=\"700\" style=\"normal\">NotoSansBengali-VF.ttf
            <axis tag=\"wght\" stylevalue=\"$Bold\"/>
        </font>" > $MODPATH/Kohinoor.xml
		
sed -i '/<family lang=\"und-Beng\" variant=\"elegant\">/,/<\/family>/{/<family lang=\"und-Beng\" variant=\"elegant\">/b;/<\/family>/b;d}' $SYSXML
sed -i "/<family lang=\"und-Beng\" variant=\"elegant\">/r $MODPATH/Kohinoor.xml" $SYSXML
sed -i '/<family lang=\"und-Beng\" variant=\"compact\">/,/<\/family>/{/<family lang=\"und-Beng\" variant=\"compact\">/b;/<\/family>/b;d}' $SYSXML
sed -i "/<family lang=\"und-Beng\" variant=\"compact\">/r $MODPATH/Kohinoor.xml" $SYSXML

ver Mono
ui_print "- Kohinoor Bangla VF"
